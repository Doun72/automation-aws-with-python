#!/bin/sh
pycodestyle webotron/
pydocstyle webotron/
pyflakes webotron/
